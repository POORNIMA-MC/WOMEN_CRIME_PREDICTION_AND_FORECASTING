from django.urls import path
from . import views
from django.views.generic.base import RedirectView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.loginpage, name='login'),
    path('signup/',views.signup,name='signup'),
    path("predict/",views.predict,name='predict'),
    path("logout/", views.logoutpage, name="logout"),
     path('login/login.html', RedirectView.as_view(url='/login/')),
     path('login/home.html', views.home, name='home_html'),
    # Add a URL pattern for 'login.html' if needed

]
