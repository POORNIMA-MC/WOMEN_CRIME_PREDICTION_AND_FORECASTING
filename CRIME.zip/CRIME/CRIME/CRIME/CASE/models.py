
from django.db import models

class YourDataset(models.Model):
    STATE_UT = models.CharField(max_length=100)
    DISTRICT= models.CharField(max_length=100)
    Year = models.IntegerField()
    Rape = models.IntegerField()
    Kidnapping_and_abduction = models.IntegerField()
    Dowry_deaths = models.IntegerField()
    Assault_on_women=models.IntegerField()
    Insult_on_women=models.IntegerField()
    Cruelty_on_women=models.IntegerField()
    Importation_of_girls=models.IntegerField()


       