import pandas as pd
from .models import YourDataset

def import_data():
    data = pd.read_csv(r"C:\Users\Manan Bedi\Documents\Crimes\CRIMESS\CRIMESS\CRIME\CRIME\CRIME\CASE\dataset\crimes.csv")
    print(len(data))
    return data
    # for row in data.iterrows():
    #     YourDataset.objects.create(
    #         STATE_UT=row['STATE/UT'],
    #         DISTRICT=row['DISTRICT'],
    #         Year=row['Year'],
    #         Rape=row['Rape'],
    #         Kidnapping_and_abduction=row['Kidnapping and Abduction'],
    #         Dowry_deaths=row['Dowry Deaths'],
    #         Assault_on_women=row['Assault on women with intent to outrage her modesty'],
    #         Insult_on_women=row['Insult to modesty of Women'],
    #         Cruelty_on_women=row['Cruelty by Husband or his Relatives'],
    #         Importation_of_girls=row['Importation of Girls'],
    #     )