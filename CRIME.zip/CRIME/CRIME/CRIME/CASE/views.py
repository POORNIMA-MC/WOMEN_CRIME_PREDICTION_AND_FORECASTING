from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth 
from django.contrib.auth import logout
from .models import YourDataset
import pandas as pd

def home(request):
    context={}
    return render(request,"home.html",context)
def loginpage(request): 

    if request.method == 'POST':
        uname = request.POST["uname"]
        password = request.POST["password"]
        user=auth.authenticate(username=uname,password=password)
        print(uname,password)
        if user is not None:
            auth.login(request,user)
            print('Working')
            return redirect('predict')

        else:
            print("Not working")
    context={}
    print("Not workingsss")
    return render(request,"login.html")
def signup(request):
    if request.method == "POST":
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password'] 
        data=User.objects.create_user(first_name=first_name,last_name=last_name,username=username,email=email,password=password) 
        data.save()
        return redirect('login')
    return render(request,"signup.html",{})
def predict(request):
    context={}
    return render(request,"predict.html",context)
def logoutpage(request):
    logout(request)
    return redirect('login')
# views.py
from django.shortcuts import render
import joblib

def predict_from_pkl(request):
    # Load all PKL models (replace with your model paths)
    model_paths = [
        'Cruelty by Husband or his Relatives_model.pkl',
        'Dowry Deaths_model.pkl',
        'Importation of Girls_model.pkl',
        'Insult to modesty of Women_model.pkl',
        'Kidnapping and Abduction_model.pkl',
        'model_and_metrics.pkl',
        'Rape_model.pkl',
    ]

    predictions = {}

    if request.method == 'POST':
        year_data = int(request.POST.get('year'))
        state_data = request.POST.get('state')
        district_data = request.POST.get('district')



        for model_path in model_paths:
            model = joblib.load(model_path)
            prediction = model.predict([[year_data,state_data,district_data]])
            print(prediction)
            predictions[model_path] = prediction

    context = {'predictions': predictions}

    return render(request, 'predictions.html', context)


def dataset_view(request):
    # Read the CSV file into a DataFrame
    file_path = r"C:\Users\gcaba\Desktop\Crimes - Updated\Crimes\CRIMESS\CRIMESS\IPYNB\updated_data.csv"
    data = pd.read_csv(file_path) 
    print(data.columns)

    # Initialize filter criteria
    state = request.POST.get('state')  # Get 'state' parameter from request
    print(state)
    district = request.POST.get('district')  # Get 'district' parameter from request
    print(district)
    year = request.POST.get('year')  # Get 'year' parameter from request
    print(year)
    print(type(state))

    # Apply filters based on user input
    if state:
        df = data[data['STATE_UT'] == state]
        print(data)
    if district:
        df1 = df[df['DISTRICT'] == district]
        print(data)
    if year:
        df2 = df1[df1['Year'] == int(year)]
        print(df2)
    # Convert the filtered data to an HTML table
    context = {'data': df2.to_dict(orient='records')} 
    print(context)
    return render(request, "datadisplay.html", context)

def analytics_view(request):
    # Your view logic goes here
    return render(request, 'analytics.html')

def redirect_to_analytics(request):
    return redirect('analytics')
