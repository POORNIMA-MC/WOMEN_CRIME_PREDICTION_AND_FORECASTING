from django import forms

class DataFilterForm(forms.Form):
    year = forms.IntegerField(label='Year')
    district = forms.CharField(max_length=100, label='District')
    state = forms.CharField(max_length=100, label='State')